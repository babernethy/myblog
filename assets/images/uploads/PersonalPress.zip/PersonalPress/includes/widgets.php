<?php include(TEMPLATEPATH . '/includes/widgets/widget-about.php'); 
include(TEMPLATEPATH . '/includes/widgets/widget-adsense.php'); 
include(TEMPLATEPATH . '/includes/widgets/widget-ads.php');
include(TEMPLATEPATH . '/includes/widgets/widget-social.php');
?>