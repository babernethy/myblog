<!--If no results are found-->
	<h1><?php _e('No Results Found','PersonalPress'); ?></h1>
	<p><?php _e('The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.','PersonalPress'); ?></p>
<!--End if no results are found-->