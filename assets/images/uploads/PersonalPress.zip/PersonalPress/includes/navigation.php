<div class="pagination">
	<div class="alignleft"><?php next_posts_link(__('&laquo; Older Entries','PersonalPress')) ?></div>
	<div class="alignright"><?php previous_posts_link(__('Next Entries &raquo;', 'PersonalPress')) ?></div>
</div>