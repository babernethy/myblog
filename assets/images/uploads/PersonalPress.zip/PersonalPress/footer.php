		</div> <!-- end #content-->
		
		<div id="footer" class="clearfix">
			<p id="copyright"><?php _e('Powered by ','PersonalPress'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php _e('Designed by ','PersonalPress'); ?> <a href="http://www.elegantthemes.com">Elegant Themes</a></p>
		</div>
	</div> <!-- end #page-wrap-->
	
	<?php include(TEMPLATEPATH . '/includes/scripts.php'); ?>
	<?php wp_footer(); ?>
</body>
</html>