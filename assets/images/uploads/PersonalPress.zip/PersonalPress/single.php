<?php get_header(); ?>
	<?php the_post(); ?>
		<div id="main">
						
			<div class="entry-wrap post">
				<div class="entry">
					<?php if (get_option('personalpress_integration_single_top') <> '' && get_option('personalpress_integrate_singletop_enable') == 'on') echo(get_option('personalpress_integration_single_top')); ?>
					
					<h1 class="title"><?php the_title(); ?></h1>
					<?php if (get_option('personalpress_postinfo2') <> '') { ?>
						<?php if ( in_array('author', get_option('personalpress_postinfo2')) || in_array('comments', get_option('personalpress_postinfo2')) || in_array('categories', get_option('personalpress_postinfo2')) ) { ?>
							<div class="post-meta clearfix">
								<?php if ( in_array('author', get_option('personalpress_postinfo2')) ) { ?>
									<span class="meta-info author">
										<span class="right-sep">
											<?php the_author_posts_link(); ?>
										</span>
									</span>
								<?php }; ?>
								
								<?php if ( in_array('comments', get_option('personalpress_postinfo2')) ) { ?>
									<span class="meta-info comments-number">
										<span class="right-sep">
											<?php comments_popup_link(__('0 comments','PersonalPress'), __('1 comment','PersonalPress'), '% '.__('comments','PersonalPress')); ?>
										</span>
									</span>
								<?php }; ?>
								
								<?php if ( in_array('categories', get_option('personalpress_postinfo2')) ) { ?>
									<span class="meta-info categories">
										<span class="right-sep">
											<?php the_category(', ') ?>
										</span>
									</span>
								<?php }; ?>
							</div> <!-- end .post-meta -->
						<?php }; ?>
					<?php }; ?>
					
					<?php if (get_option('personalpress_postinfo2') <> '') { ?>
						<?php if ( in_array('date', get_option('personalpress_postinfo2')) ) { ?>
							<p class="date">
								<span class="month"><?php the_time('M'); ?></span>
								<span class="day"><?php the_time('d'); ?></span>
							</p>
						<?php }; ?>
					<?php }; ?>
					
					<div class="entry-content clearfix post">
					
						<?php $thumb = '';
							  $width = 175;
							  $height = 175;
							  $classtext = '';
							  $titletext = get_the_title();
							
							  $thumbnail = get_thumbnail($width,$height,$classtext,$titletext,$titletext);
							  $thumb = $thumbnail["thumb"]; ?>
							  
						<?php if($thumb <> '' && get_option('personalpress_thumbnails') == 'on') { ?>						
							<div class="thumb">
								<?php print_thumbnail($thumb, $thumbnail["use_timthumb"], $titletext, $width, $height, $classtext); ?>
								
								<span class="overlay"></span>
							</div> <!-- end .thumb -->
						<?php }; ?>

						<?php the_content(); ?>
						<?php wp_link_pages(array('before' => '<p><strong>'.__('Pages','PersonalPress').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
						<?php edit_post_link(__('Edit this page','PersonalPress')); ?>
						
						<?php if (get_option('personalpress_integration_single_bottom') <> '' && get_option('personalpress_integrate_singlebottom_enable') == 'on') echo(get_option('personalpress_integration_single_bottom')); ?>		
						<?php if (get_option('personalpress_468_enable') == 'on') { ?>
							<?php if(get_option('personalpress_468_adsense') <> '') echo(get_option('personalpress_468_adsense'));
							else { ?>
								<a href="<?php echo(get_option('personalpress_468_url')); ?>"><img src="<?php echo(get_option('personalpress_468_image')); ?>" alt="468 ad" class="foursixeight" /></a>
							<?php } ?>	
						<?php } ?>
						
					</div> <!-- end .entry-content -->
					
					<div class="entry-bottom"></div>

				</div> <!-- end .entry -->
			</div> <!-- end .entry-wrap -->
			
			<?php if (get_option('personalpress_show_postcomments') == 'on') comments_template('', true); ?>
			
		</div> <!-- end #main -->	
<?php get_sidebar(); ?>
<?php get_footer(); ?>