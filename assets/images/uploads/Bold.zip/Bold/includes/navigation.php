<p class="pagination">
    <?php next_posts_link(__('&laquo; Previous Entries','Bold')) ?>
	<?php previous_posts_link(__('Next Entries &raquo;','Bold')) ?>
</p>