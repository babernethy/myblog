 <a href="<?php echo(get_option('bold_468_url'));?>"><img src="<?php echo(get_option('bold_468_image'));?>" alt="banner ad" style="float: left; margin-left: 70px; border: none;" /></a>
<div style="clear: both;"></div>
