<div class="pagination clearfix">
	<div class="alignleft"><?php next_posts_link(__('&laquo; Older Entries','InReview')) ?></div>
	<div class="alignright"><?php previous_posts_link(__('Next Entries &raquo;', 'InReview')) ?></div>
</div>